<?php
system("clear");
error_reporting(0);
// warna
$biru="\033[1;34m";
$kuning="\033[1;33m";
$merah="\033[1;31m";
$putih="\033[1;37m";
$hijau="\033[1;32m";
$cyan="\033[1;36m";
$ungu="\033[1;35m";
$dark="\033[1;30m";
$abu = "\033[0;90m";
$abu1 = "\033[1;90m";
$merah1 = "\033[1;91m";
$end = "\033[0m";
$blockabu = "\033[100m";
$blockmerah = "\033[101m";
$blockstabilo = "\033[102m";
$blockkuning = "\033[103m";
$blockbiru = "\033[104m";
$blockpink = "\033[105m";
$blockcyan = "\033[106m";
$blockputih = "\033[107m";
$panah = $hijau."⟫ ";
$r= "\r                                                                    \r";
@error_reporting(E_ALL ^ (E_NOTICE | E_WARNING)); 
function an($str){$arr = str_split($str); 
foreach ($arr as $az){echo $az; usleep(3000);}}

function curl($url, $post = 0, $httpheader = 0, $proxy = 0){ 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_COOKIE,TRUE);

if($post){
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);}
if($httpheader){
curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);}
if($proxy){
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, true);
curl_setopt($ch, CURLOPT_PROXY, $proxy);}
curl_setopt($ch, CURLOPT_HEADER, true);
$response = curl_exec($ch);
$httpcode = curl_getinfo($ch);
if(!$httpcode) return "Curl Error : ".curl_error($ch); else{
$header = substr($response, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
$body = substr($response, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
curl_close($ch);
return array($header, $body);}}
    
function vision($data){$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://vision.googleapis.com/v1/images:annotate?key=AIzaSyC3y-Em42htSB8UEZPqptJ78rlvL58_h6Y");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

$visit = array();
$visit[] = "User-Agent: Mozilla/5.0 (Linux; Android 11; M2004J19C Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile Safari/537.36";
$visit[] = "content-type: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $visit);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
return curl_exec($ch);}
function base64($str){return base64_encode($str);}

function save($data,$data_post){
if(!file_get_contents($data)){
file_put_contents($data,"[]");}
$json=json_decode(file_get_contents($data),1);
$arr=array_merge($json,$data_post);
file_put_contents($data,json_encode($arr,JSON_PRETTY_PRINT));}

if(!file_exists("data.json")){
system("clear");
$useragent=readline("Input Your User-agent : ");echo"\n";
$cookie=readline("Input Your Cookie : ");echo"\n";
$solve=readline("Input Your Url Solvemedia : ");echo"\n";

$data=["User-agent"=>$useragent,"Cookie"=>$cookie,"Solvemedia"=>$solve,];
save("data.json",$data);}
$solve=json_decode(file_get_contents("data.json"),true)["Solvemedia"];
function head(){
$useragent=json_decode(file_get_contents("data.json"),true)["User-agent"];
  $cookie=json_decode(file_get_contents("data.json"),true)["Cookie"];
  $h[]="Host: faucetgo.space";
  $h[]="upgrade-insecure-requests: 1";
  $h[]="User-Agent: $useragent";
  $h[]="referer: https://faucetgo.space/";
  $h[]="accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7";
  $h[]="cookie: $cookie";
 return $h;}

function solve(){
$useragent=json_decode(file_get_contents("data.json"),true)["User-agent"];
  $h[]="Host: api-secure.solvemedia.com";
  $h[]="user-agent: $useragent";
  $h[]="accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7";
  $h[]="accept: image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8";
  $h[]="sec-gpc: 1";
 return $h;}

function getsolve($url){
  return curl($url,'',solve())[1];}

function get($url){
  return curl($url,'',head())[1];}

function post($url,$data){
  return curl($url,$data,head())[1];}

function timer(){
for($x=65;$x>-1;$x--){
  echo "\r                                           \r";
  echo "\r".$blockabu.$panah.$putih."Claim Ulang Setelah ".$x." Seconds".$end."\r";
 sleep(1);}
echo$r;}

system("clear");

echo $hijau."═════";usleep(100000);echo$hijau."══════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═══";usleep(100000);echo$hijau."══════";usleep(100000);echo$hijau."════════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═══";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."═══\n"; 
usleep(100000);
echo an($baner1 = $merah. "
            ███╗██╗   ██╗███╗         ██╗ █████╗ ██╗   ██╗
            ██╔╝██║   ██║╚██║         ██║██╔══██╗╚██╗ ██╔╝
            ██║ ██║   ██║ ██║         ██║███████║ ╚████╔╝ 
            ██║ ╚██╗ ██╔╝ ██║    ██   ██║██╔══██║  ╚██╔╝  
            ███╗ ╚████╔╝ ███║    ╚█████╔╝██║  ██║   ██║   
            ╚══╝  ╚═══╝  ╚══╝     ╚════╝ ╚═╝  ╚═╝   ╚═╝\n" );
echo $hijau."═════";usleep(100000);echo$hijau."══════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═══";usleep(100000);echo$hijau."══════";usleep(100000);echo$hijau."════════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═══";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."═══\n"; 
usleep(100000);
echo $panah.$cyan."•[ ";usleep(100000);echo$cyan."S";usleep(100000);echo$cyan."c";usleep(100000);echo$cyan."r";usleep(100000);echo$cyan."i";usleep(100000);echo$cyan."p";usleep(100000);echo$cyan."t";
usleep(100000);
echo" N";usleep(100000);echo$cyan."a";usleep(100000);echo$cyan."m";usleep(100000);echo$cyan."e :";usleep(100000);echo$cyan."";
usleep(100000);
echo$kuning." faucetgo.space".$cyan." ]• ";usleep(100000);echo$cyan."\n"; 
usleep(100000);
echo $panah.$cyan."•[ ";usleep(100000);echo$cyan."C";usleep(100000);echo$cyan."r";usleep(100000);echo$cyan."e";usleep(100000);echo$cyan."a";usleep(100000);echo$cyan."t";usleep(100000);echo$cyan."e";usleep(100000);echo$cyan."d ";usleep(100000);echo$cyan."B";usleep(100000);echo$cyan."y";usleep(100000);echo$cyan."  :";
usleep(100000);
echo$kuning." [V] Jay Official".$cyan." ]•\n"; 
usleep(100000);
echo $panah.$cyan."•[ ";usleep(100000);echo$cyan."T";usleep(100000);echo$cyan."h";usleep(100000);echo$cyan."a";usleep(100000);echo$cyan."n";usleep(100000);echo$cyan."k";usleep(100000);echo$cyan."s";usleep(100000);echo$cyan." F";usleep(100000);echo$cyan."o";usleep(100000);echo$cyan."r ";usleep(100000);echo$cyan." :";usleep(100000);echo$cyan."".$kuning." All Creator Function ".$cyan." ]•\n";
usleep(10000);
echo $panah.$cyan."•[ ";usleep(100000);echo$cyan."D";usleep(100000);echo$cyan."o";usleep(100000);echo$cyan."n";usleep(100000);echo$cyan."a";usleep(100000);echo$cyan."t";usleep(100000);echo$cyan."e ";usleep(100000);echo$cyan."T";usleep(100000);echo$cyan."r";usleep(100000);echo$cyan."x  ";usleep(100000);echo$cyan.":".$kuning." TNREHtxijDzfDvfPC4STXtYQDPpmDV1RpN".$cyan." ";usleep(100000);echo$cyan."]•";usleep(100000);echo$cyan."\n";usleep(10000);
echo $hijau."═════";usleep(100000);echo$hijau."══════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═══";usleep(100000);echo$hijau."══════";usleep(100000);echo$hijau."════════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═══";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."═══\n"; 
usleep(10000);
//dasboard
$url="https://faucetgo.space/dashboard";
$res= get($url);
$user=explode('<span class="d-none d-sm-inline-block ml-1">',$res)[1];
$user=explode('</span>',$user)[0];
$balance=explode('class="mb-0">',$res)[1];
$balance=explode('</h5>',$balance)[0];


echo $panah.$cyan."•[ ".$putih."User Id     : ".$kuning.$user.$cyan." ]•\n"; 
echo $panah.$cyan."•[ ".$putih."Balance     : ".$kuning.$balance."Usd".$cyan." ]•\n"; 

$url="https://faucetgo.space/faucet";
$res= get($url);
$minut=explode('</p>',explode('<p class="lh-1 mb-1 font-weight-bold">',$res)[1])[0];
$per=explode('</p>',explode('<p class="lh-1 mb-1 font-weight-bold">',$res)[2])[0];
$claim=explode('</p>',explode('<p class="lh-1 mb-1 font-weight-bold">',$res)[3])[0];

echo $panah.$cyan."•[ ".$putih."Menit Claim : ".$kuning.$minut." Minutes".$cyan." ]•\n"; 
echo $panah.$cyan."•[ ".$putih."Per Claim   : ".$kuning.$per."USD".$cyan." ]•\n";
echo $panah.$cyan."•[ ".$putih."Total Claim : ".$kuning.$claim.$cyan." ]•\n"; 

echo $hijau."═════";usleep(100000);echo$hijau."══════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═══";usleep(100000);echo$hijau."══════";usleep(100000);echo$hijau."════════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."════";usleep(100000);echo$hijau."═══";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."═══\n"; 

echo $panah.$blockputih.$dark."HARAP MASUKAN NOMER..!".$end."\n";
echo $panah.$cyan."[1] Auto Captcha\n";
echo $panah.$cyan."[2] Manual Captcha\n";
echo $panah.$cyan."[3] Exit\n";
$menu = readline($panah.$merah."Please select : ");

echo $hijau."═════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════\n";

if($menu==1){echo an($panah.$blockmerah.$putih."Auto Bypass Captcha Solvemedia".$end."\n");

echo $hijau."═════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════\n";

while("true"){
while("true"){
$url="https://faucetgo.space/faucet";
$res= get($url);
$csrf=explode('"',explode('id="token" value="',$res)[1])[0];
$token=explode('"',explode('name="token" value="',$res)[1])[0];
$res= getsolve($solve);
$challenge=explode('"',explode('"challenge":"',$res)[1])[0];

$url="https://api-secure.solvemedia.com/papi/media?c=$challenge;w=300;h=150;fg=000000;bg=f8f8f8";
$result=getsolve($url);
$img="image.png";
$file=fopen($img,"w");
fwrite($file,$result);
fclose($file);
$gmbar=file_get_contents("image.png");
$base=base64($gmbar);
$convert = vision('{"requests":[{"image":{"content":"'.$base.'"},"features":[{"type":"TEXT_DETECTION"}]}]}');
$pro= explode('"text": "Enter the following:\n', $convert);
$ses = explode('\n"', $pro[1]);
$proses = $ses[0];
$replace = preg_replace("/[^a-zA-Z]/", "", $proses);
$url="https://faucetgo.space/faucet/verify";
$data="csrf_token_name=$csrf&token=$token&captcha=solvemedia&g-recaptcha-response=&adcopy_response=$replace&adcopy_challenge=$challenge";
$res= post($url,$data);
$res=explode('has been added to your balance',explode("Good job!', '",$res)[1])[0];
$token=explode('"',explode('name="token" value="',$res)[1])[0];
if(!$res==""){

echo $panah.$blockputih.$dark."Sukses Bypass Captcha Solvemedia".$end."\n";
echo $panah.$putih."Masuk Balance : ".$kuning.$res."\n";

system("rm -r image.png");
break;
}else{
echo an($panah.$blockmerah.$putih."GAGAL BYPASS CAPTCHA ".$end); 
sleep(2);
echo$r;
echo an($panah.$blockmerah.$putih."Menghapus Image ".$end); 
sleep(2);
system("rm -r image.png");
echo$r;
echo an($panah.$blockmerah.$putih."Memulai Ulang ".$end);
sleep(2);
echo$r;}}
$url="https://faucetgo.space/dashboard";
$res= get($url);
$balance=explode('class="mb-0">',$res)[1];
$balance=explode('</h5>',$balance)[0];
echo $panah.$putih."Balance     : ".$kuning.$balance."USD\n";
$url="https://faucetgo.space/faucet";
$res= get($url);
$claim=explode('</p>',explode('<p class="lh-1 mb-1 font-weight-bold">',$res)[3])[0];
echo $panah.$putih."Total Claim : ".$kuning.$claim."\n";
echo $hijau."═════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════\n";

for($x=62;$x>-1;$x--){
  echo "\r                                           \r";
  echo "\r".$panah.$blockabu.$putih."Claim Ulang Setelah ".$x." Seconds".$end."\r";
 sleep(1);}
echo$r;}}

if($menu==2){echo an($panah.$blockmerah.$putih."Manual Captcha Solvemedia".$end."\n");

echo $hijau."═════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════\n";
while("true"){
while("true"){
$url="https://faucetgo.space/faucet";
$res= get($url);
$csrf=explode('"',explode('id="token" value="',$res)[1])[0];
$token=explode('"',explode('name="token" value="',$res)[1])[0];
$res= getsolve($solve);
$challenge=explode('"',explode('"challenge":"',$res)[1])[0];

$url="https://api-secure.solvemedia.com/papi/media?c=$challenge;w=300;h=150;fg=000000;bg=f8f8f8";
$result=getsolve($url);
$img="image.png";
$file=fopen($img,"w");
fwrite($file,$result);
fclose($file);

$cap= system("termux-open image.png");
while("true"){
$cap=readline($panah.$blockmerah.$putih."Input Captcha".$end." : ");
if(!$cap==""){
break;}}
$url="https://faucetgo.space/faucet/verify";
$data="csrf_token_name=$csrf&token=$token&captcha=solvemedia&g-recaptcha-response=&adcopy_response=$cap&adcopy_challenge=$challenge";
$res= post($url,$data);
$res=explode('has been added to your balance',explode("Good job!', '",$res)[1])[0];
$token=explode('"',explode('name="token" value="',$res)[1])[0];
if(!$res==""){

echo $hijau."═════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════\n";

echo $panah.$blockputih.$dark."Sukses Bypass Captcha Solvemedia".$end."\n";
echo $panah.$putih."Masuk Balance : ".$kuning.$res."\n";

system("rm -r image.png");
break;
}else{
echo an($panah.$blockmerah.$putih."GAGAL BYPASS CAPTCHA ".$end); 
sleep(2);
echo$r;
echo an($panah.$blockmerah.$putih."Menghapus Image ".$end); 
sleep(2);
system("rm -r image.png");
echo$r;
echo an($panah.$blockmerah.$putih."Memulai Ulang ".$end);
sleep(2);
echo$r;}}

$url="https://faucetgo.space/dashboard";
$res= get($url);
$balance=explode('class="mb-0">',$res)[1];
$balance=explode('</h5>',$balance)[0];

echo $panah.$putih."Balance     : ".$kuning.$balance."USD\n";
$url="https://faucetgo.space/faucet";
$res= get($url);
$claim=explode('</p>',explode('<p class="lh-1 mb-1 font-weight-bold">',$res)[3])[0];
echo $panah.$putih."Total Claim : ".$kuning.$claim."\n";

echo $hijau."═════";usleep(100000);echo$hijau."═════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════";usleep(100000);echo$hijau."═══════\n";

for($x=62;$x>-1;$x--){
  echo "\r                                           \r";
  echo "\r".$panah.$blockabu.$putih."Claim Ulang Setelah ".$x." Seconds".$end."\r";
 sleep(1);}
echo$r;}}

