<?php

//Isi USER-AGENT Sesuai Data Kalian
$user = 'xxxx';

//Isi Cookie Sesuai Data Kalian
$cookie = 'xxxx';
