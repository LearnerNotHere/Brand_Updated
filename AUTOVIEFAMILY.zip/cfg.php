<?php

$useragent = "xxxx";

//dogehero.xyz
$ck2 = "xxxx";

//cryptoaffiliates.store
$ck1 = 'xxxx';

//1xbitcoins.com
$ck3 = "xxxx";

//btcbunch.com
$ck4 = 'xxxx";

//free.shiba.limited
$ck5 = "xxxx";

